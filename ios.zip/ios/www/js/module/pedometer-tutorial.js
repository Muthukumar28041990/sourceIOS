define(["jquery", "./common.js", "./tutorial.js"], function($, commonModule, tutorialModule) {
    console.log("Loading pedometer-tutorial.js");

    var pedometerModuleTutorial = {
        tutorialObj: {
            tutorialName: "pedometer-tutorial",
            tutorialId: "#pedometer-tutorial-carousel",
            url: "../tutorials/pedometer-tutorial.html"
        },
        initialize: function() {
            // tutorial Initialize
            this.tutorial(this.tutorialObj);
        },
        tutorial: function(options) {

            // Before Page show event
            $(document).on("pagecontainerbeforeshow", function(e, ui) {
                var newPageID = ui.toPage.prop("id");
                var tut = commonModule.storage.getItem(options.tutorialName);
                if ((newPageID == "pedometer") && (!tut)) {
                    pedometerModuleTutorial.startTutorial(options)
                } else {
                    //pedometerModule.removeTutorial(options.tutorialId);
                }
            });
            // On Page show Event

        },
        startTutorial: function(options) {
            tutorialModule.initTutorialCarousel(options);
            $(document).on("vclick", "#ok", function(e) {
                e.stopImmediatePropagation();
                e.preventDefault();
                commonModule.storage.setItem(options.tutorialName, "true");
                pedometerModuleTutorial.removeTutorial(options.tutorialId);
            });
        },
        removeTutorial: function(tutorialId) {
            $(tutorialId).remove();
            $('body').removeClass("overflowH");
        },


    };
    return pedometerModuleTutorial;
});