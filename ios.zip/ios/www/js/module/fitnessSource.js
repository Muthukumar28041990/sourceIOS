define(["jquery", "./common.js", "./cordova.service.js", "./mljdbproc.js", "./mljDate.js", "./mljWalkConstants.js", "./mljObjectModel.js", "./synchronisation.js", "./clientService.js"], function($, commonModule, cordovaModule, mljdbproc, mljDate, mljdbConstantModule, mljObjectModel, synchronisation, clientService) {
    var misfitHandler = null;
    var fitnessSourceModule = {
        sso: null,
        invocationData: {},
        misfit : require('node-misfit'),
        initialize: function() {
            if(device.platform !="iOS")
            {
                cordovaModule.isLocationEnabled();
            }
            else
            {
                cordova.plugins.backgroundMode.disable();
       
               if(window.watchId != null || window.watchId != undefined)
               {
                    navigator.geolocation.clearWatch(window.stepcountWatchIntervalID);
               }
            }
            synchronisation.updateStepCountinDashboard();
       
            fitnessSourceModule.sso = JSON.parse(commonModule.storage.getItem("sso"));
            //fitnessSourceModule.sso.source = "misfit";    // TODO: hardcoded to googlefit for this build, has to be changed.
            if(fitnessSourceModule.sso.goofitEnabled == true)
            {
                if(device.platform == "iOS")
                {
                     $("#loading-indicator").show();
                    synchronisation.updateDBforLastsevenDays();
                }
                else
                {
                    fitnessSourceModule.syncStepwithDB();    
                }
                
            }
        	switch (fitnessSourceModule.sso.source) {
                case stepSource[0]://googlefit
                if(fitnessSourceModule.sso.goofitEnabled != true)
                {
                    navigator.health.isAvailable(function(){
                     cordovaModule.requestAuthorization(function(data){
                        if(device.platform == "iOS"){data="OK"}
                        if(data === "OK"){
                            console.log("googlefit enabled");
                            commonModule.updateSSO({goofitEnabled: true});                            
                            cordovaModule.isPedometerAvailable(function(isAvail) {
                            if (isAvail) {
                                // Stop the pedometer count
                                isPedoStarted = localStorage.getItem("isPedoStarted")
                                if(device.platform!="iOS"){
                                    if (isPedoStarted == "true") {
                                            cordovaModule.stopPedometer();
                                    }
                                }
                                //start  the pedometer
                                cordovaModule.startPedometer(fitnessSourceModule.syncStepwithDB);
                                //Get the pedometer count value 
                            } else {
                                navigator.notification.alert(pedometerErrorMsg);
                            }
                            });
                            if(device.platform == "iOS")
                            {
                                    $("#loading-indicator").show();
                                    synchronisation.updateDBforLastsevenDays();
                            }
                            setInterval(fitnessSourceModule.syncStepwithDB, getSourceInterval)
                             
                         }
                         else
                         {
                                // TODO : if google fit is not available or user cancelled the popUp
                         }
                        });
                    }, function(){
                     navigator.notification.alert("Google/Health fit is not available is your device");   
                    })                    
                }                    
                break;
                case stepSource[1]://fitbit
                    if(cordovaModule.connection()){
                        var fbConfig = {
                            client_id: "227P3D",
                            scope: "activity",
                            redirect_uri: "http://localhost",
                            expires_in: "2592000"
                        };
                        var url = "https://www.fitbit.com/oauth2/authorize?response_type=token&client_id=" + fbConfig.client_id + "&redirect_uri=" + fbConfig.redirect_uri + "&scope=" + fbConfig.scope + "&expires_in=" + fbConfig.expires_in;
                        if(fitnessSourceModule.sso.fitbitToken === null || fitnessSourceModule.sso.fitbitToken === undefined){
                            fitnessSourceModule.getAuthToken(url).then(function(code){
                                if(code !== null){                                
                                    commonModule.updateSSO({fitbitToken : code});
                                    setInterval(fitnessSourceModule.getDataFromFitbit, getSourceInterval);
                                    fitnessSourceModule.getDataFromFitbit();
                                }
                                else {
                                    navigator.notification.alert(usernotregisteredwithfitbit);
                                }
                            },function(error){
                                delete fitnessSourceModule.sso.source;
                                commonModule.updateSSO({
                                    source: stepSource[4],
                                    fitnessSourceSelectedDate: new Date(),
                                    fitnessSourceSelectedCount: 0
                                });
                            });
                        }
                        else{
                            fitnessSourceModule.getDataFromFitbit();
                        }
                    }
                break;
                case stepSource[2]://misfit
                    if(cordovaModule.connection()){
                        misfitHandler = new this.misfit({
                            clientId: 'XsweTZwRNWxYMDR8',
                            clientSecret: '4Ww8yG1MDjGMNgJeL8mS0jOfFfKwXaiv',
                            redirectUri: 'http://localhost'
                        });
                        if(fitnessSourceModule.sso.misfitToken === null || fitnessSourceModule.sso.misfitToken === undefined){
                            fitnessSourceModule.setMisfitToken().then(function(result){
                                if(result.code !== null && result.code.length > 0 && result.status){
                                    misfitHandler.getAccessToken(result.code[1], function(err, token){
                                        commonModule.updateSSO({misfitToken : token});
                                        setInterval(fitnessSourceModule.getDataFromMisfit, getSourceInterval);
                                        fitnessSourceModule.getDataFromMisfit();//fitnessSourceModule.sso.lastUploadSyncToSFDC, new Date()
                                    });
                                }
                                else {
                                    navigator.notification.alert(usernotregisteredwithmisfit);
                                }
                            },function(error){
                                delete fitnessSourceModule.sso.source;
                                commonModule.updateSSO({
                                    source: stepSource[4],
                                    fitnessSourceSelectedDate: new Date(),
                                    fitnessSourceSelectedCount: 0
                                });
                            });
                        }
                        else{
                            fitnessSourceModule.getDataFromMisfit();//fitnessSourceModule.sso.lastUploadSyncToSFDC, new Date()
                        }
                    }
                break;
                case stepSource[4]://donotset
                	navigator.notification.alert(usernotmappedwithfitnesssource);
                	break;
                default:
                    navigator.notification.alert(usernotmappedwithfitnesssource);
                	break;
            }
        },
        syncStepwithDB:function(){
            if(device.platform == "iOS")
            {
                //$("#loading-indicator").show();
                synchronisation.updateStepCountinDashboard(); 
            }
            else
            {
                cordovaModule.getTodayStepCount(function(data){ console.log("sync data= "+data)
                var lastSyncedTime = commonModule.storage.getItem("lastSyncedTime");
                var endDateTime;
                var startDateTime;
                var googleFitstartDateTime;
                var userCountStepHourly;
                if(lastSyncedTime == null)
                {
                    endDateTime = new Date();endDateTime = new Date();
                    var enddateCalc = new Date().setHours(new Date().getHours() - 1);
                     googleFitstartDateTime = new Date(enddateCalc) 
                    startDateTime = mljDate.getMLJLastHourDatetime(); 
                }
                else
                {                        
                    endDateTime = new Date();
                    var enddateCalc = new Date().setHours(new Date().getHours() - 1);
                    googleFitstartDateTime = new Date(enddateCalc) 
                    startDateTime = mljDate.getMLJLastHourDatetime(); 
                    console.log("nt null--endDateTime="+endDateTime);
                    console.log("nt null--startDateTime="+startDateTime);
                }
                var data = (data == null) ? 0 : data;
                var lastSyncData =commonModule.storage.getItem("stepsToSync");
                commonModule.storage.setItem("stepsToSync",data);
                if(lastSyncData != null)
                {
                    var lastSyncedValue = new Date(lastSyncedTime);
                    var lastSyncedDate = lastSyncedValue.getDate();
                    var today = new Date();
                    var currentDate = today.getDate();
                    if(lastSyncedDate == currentDate)
                    {
                        userCountStepHourly = data- parseInt(lastSyncData);
                    }
                    else
                    {
                        userCountStepHourly = data;   
                    } 
                    commonModule.storage.setItem("stepsToSync",data);
                }
                else
                {
                    commonModule.storage.setItem("stepsToSync",data);
                      userCountStepHourly = data;
                }
                var campaignObj = commonModule.activeCampaignDetails.getItem;
                campaignId = ( campaignObj == null || campaignObj == undefined) ? null :campaignObj.campaignId;
                var lastUpdatedTime =  mljDate.getMLJCurrentDatetime();
           
                var query  = "Insert into mljCampaignTransaction (campaignId,achievedStepCount,source,lastUpdatedTime,startDateTime) VALUES(?,?,?,?,?)"; 
                if(userCountStepHourly > 1)
                {
                    $.when(mljdbproc.query(query, [campaignId,userCountStepHourly,"googlefit",lastUpdatedTime,startDateTime])).then(function(result){
                         console.log("steps synced with local DB"+result);
                         synchronisation.updateStepCountinDashboard();
                         commonModule.storage.setItem("lastSyncedTime",lastUpdatedTime);
                });
                    
                if(device.platform !="iOS")
                {
                    cordovaModule.storeGoogle(googleFitstartDateTime,endDateTime,userCountStepHourly,function(data){
                        console.log("saved to googlefit");
                    });
                }
                }
            });       
       }
            
        },
        setMisfitToken : function(){
            var deferred = $.Deferred();
            if(misfitHandler !== null && misfitHandler !== undefined){
                var authorizeUrl = misfitHandler.getAuthorizeUrl();                        
                fitnessSourceModule.getAuthToken(authorizeUrl).then(function(code){
                    deferred.resolve({status: true, code: code});
                }, function(code){
                    if(code === null) deferred.reject({status: false, code: null});
                });
            }
            else deferred.reject({status: false, code: null});
            return deferred.promise();
        },
        getDataFromFitbit : function(startDate, endDate){
            var deferred = $.Deferred();
            fitnessSourceModule.sso = JSON.parse(commonModule.storage.getItem("sso"));            
            startDate = (typeof startDate !== "undefined") ? mljDate.getMLJCurrentDate(startDate) : mljDate.getMLJCurrentDate();
            endDate = (typeof endDate !== "undefined") ? mljDate.getMLJCurrentDate(endDate) : mljDate.getMLJCurrentDate();
            fitnessSourceModule.invocationData.url = fitbitapi + '/activities/date/' + startDate + '.json';
            fitnessSourceModule.invocationData.type = "GET";
            var request  = clientService.fitbitRequest(fitnessSourceModule.invocationData);
            request.done(function(response) {
                if(response !== null && response !== undefined && response.summary !== undefined){
                    var fitbitObj = {
                        startDate: startDate,
                        endDate: endDate,
                        steps:response.summary.steps
                    };
                    fitnessSourceModule.getTransactionData(fitbitObj).then(function(result){
                        if(result){
                            commonModule.updateSSO({fitbitLastHourSteps : response.summary.steps});
                        }
                        deferred.resolve(true);
                    },function(error){
                        deferred.reject(false);    
                    });
                }
                else{
                   deferred.reject(false); 
                }
            });
            request.fail(function (error) {
                error.responseText = (error.responseText==='' && error.responseText === undefined) ? 'unknown error' : error.responseText;
                console.log(error.responseText);
            });
            return deferred.promise();            
        },
        getDataFromMisfit : function(startDate, endDate){
            var deferred = $.Deferred();
            fitnessSourceModule.sso = JSON.parse(commonModule.storage.getItem("sso"));
            startDate = (typeof startDate !== "undefined") ? mljDate.getMLJCurrentDate(startDate) : mljDate.getMLJCurrentDate();
            endDate = (typeof endDate !== "undefined") ? mljDate.getMLJCurrentDate(endDate) : mljDate.getMLJCurrentDate();
            if(misfitHandler !== null && misfitHandler !== undefined && fitnessSourceModule.sso.misfitToken !== undefined){
                misfitHandler.getSummary(fitnessSourceModule.sso.misfitToken, startDate, endDate, {detail: true}, function(err, summary){
                    if(summary !== null && summary !== undefined && summary.summary.length > 0){
                        /*var totalSteps = 0;
                        $.each(summary.summary, function(index, obj) {
                            totalSteps +=obj.steps;
                        });*/
                        var misfitObj = {
                            startDate: startDate,
                            endDate: endDate,
                            steps: summary.summary[0].steps//totalSteps
                        };
                        fitnessSourceModule.getTransactionData(misfitObj).then(function(result){
                            if(result){
                                commonModule.updateSSO({misfitLastHourSteps : summary.summary[0].steps});
                            }
                            deferred.resolve(true);
                        },function(error){
                            deferred.reject(false);    
                        });
                    }
                    else{
                        deferred.reject(false);
                    }
                });
            }
            else{
                deferred.reject(false);
            }
            return deferred.promise();
        },
        getTransactionData : function(datasource){
            var deferred = $.Deferred(), transactionData = {}, lastHourSyncSteps, stepCount = 0, lastHourSyncProperty;
            var campaignObj = commonModule.activeCampaignDetails.getItem;
            transactionData.campaignId = (campaignObj === null || campaignObj === undefined) ? null : campaignObj.campaignId;
            transactionData.achievedStepCount = datasource.steps;
            lastHourSyncSteps = fitnessSourceModule.sso.source === 'misfit' ? fitnessSourceModule.sso.misfitLastHourSteps : fitnessSourceModule.sso.fitbitLastHourSteps;
            //lastHourSyncProperty = fitnessSourceModule.sso.source === 'misfit' ? 'misfitLastHourSteps' : 'fitbitLastHourSteps';
            if(lastHourSyncSteps !== undefined && parseInt(datasource.steps) >= parseInt(lastHourSyncSteps)){
                stepCount = parseInt(datasource.steps) - parseInt(lastHourSyncSteps);
                transactionData.achievedStepCount = stepCount.toString();                
            }
            transactionData.source = fitnessSourceModule.sso.source;
            transactionData.lastUpdatedTime = mljDate.getMLJCurrentDatetime();
            transactionData.startDateTime = mljDate.getMLJLastHourDatetime();
            fitnessSourceModule.setTransactionData(transactionData).then(function(result){
                if(result) {
                    synchronisation.updateStepCountinDashboard();
                    deferred.resolve(true);
                }
                else deferred.reject(false);
            });
            return deferred.promise();
        },
        setTransactionData : function(transactionData) {
            var deferred = $.Deferred();
            var registry = mljdbproc.colDefinition(mljdbConstantModule.tables[1].columns);
            var insertQ = 'INSERT INTO ' + mljdbConstantModule.tables[1].name + ' (' + (registry.columnNameColl.join(',')) + ') VALUES (' + (registry.columnValColl.join(',')) + ')';
            registry.columnVal = [{}];
            registry.columnVal[0] = mljdbproc.mljColMapper(mljObjectModel.campaignTransaction, transactionData);
            var invocationData = {
                tablename: mljdbConstantModule.tables[1].name,
                seed: registry.columnVal[0],
                query: insertQ
            };
            $.when(mljdbproc.mljSetDataInDB(invocationData)).then(function(result) {
                if (!result) {
                    //call common error module
                    deferred.reject(false);
                }
                else deferred.resolve(true);
            });
            return deferred.promise();
        },
        getAuthToken : function(authorizeUrl){
            var deferred = $.Deferred(), code = null, authError = null;
            if(authorizeUrl !== null && authorizeUrl !== undefined){
                var authWindow = window.open(authorizeUrl, '_blank', 'location=yes,toolbar=yes');
                $(authWindow).on('loadstart', function(e) {
                    var url = e.originalEvent.url;
                    if(fitnessSourceModule.sso.source !== stepSource[1]) code = /\?code=(.+)$/.exec(url);
                    else if(fitnessSourceModule.sso.source === stepSource[1] && url !== null && url.indexOf('access_token') > 0){
                        code = url.split('&').filter(function(el) { if(el.match('token_type') !== null) return true; })[0].split('=')[1] + ' ' +
                               url.split('&').filter(function(el) { if(el.match('access_token') !== null) return true; })[0].split('=')[1];
                    }
                    authError = /\?error=(.+)$/.exec(url);
                    if (code || authError) {
                        authWindow.close();
                        deferred.resolve(code);
                    }                    
                });
                $(authWindow).on('exit', function(result){
                    if(code === null) deferred.reject(code);
                });
            }
            else deferred.reject(code);
            return deferred.promise();
        }
    };
    return fitnessSourceModule;
});