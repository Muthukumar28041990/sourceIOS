define(["jquery"], function($) {
	var mljObjectmodel = {
		campaignMaster : {
			campaignId : null,
		    campaignName : null,
		    campaignStartDate : null,
		    campaignEndDate : null,
		    bannerImageUri : null,
		    campaignTarget : null,
		    inventoryBalance : null,
		    inventoryType : null,
		    inventoryName : null,
		    inventoryImage : null,
		    campaignDescription : null,
		    campaignFooterNote : null,
		    prizesToBeClaimed : null,
		    totalPrizeDonated : null,
		    achievedStepCount : null,
		    status : null,
		    lastUpdatedTime : null
		},
		userProfile : {
			email : null,
		    nickname : null,
		    gender : null,
		    yob : null,
		    deviceId : null,
		    dailyTarget : null,
		    oAuthToken : null,
		    bodyOfAttachment : null,
		    fileName : null,
		    batchNo : null,
		    activeCampaignId : null,
		    source: null,
		    lastUpdatedTime : null
		},
		campaignTransaction : {
			campaignId : null,
			achievedStepCount : null,
		    source : null,
			lastUpdatedTime : null,
		    startDateTime : null
		}
    };
    return mljObjectmodel;
});