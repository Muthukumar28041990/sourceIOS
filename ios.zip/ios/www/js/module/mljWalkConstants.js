define(["jquery"], function($) {
	var mljdbConstantModule = {
            tables : [{
		name:'mljCampaignMaster',
		columns:[
			{name: 'campaignId', type: 'TEXT PRIMARY KEY NOT NULL'},
			{name: 'campaignName', type: 'TEXT'},
			{name: 'campaignStartDate', type: 'TEXT'},
			{name: 'campaignEndDate', type: 'TEXT'},
			{name: 'bannerImageUri', type: 'TEXT'},
			{name: 'campaignTarget', type: 'TEXT'},
			{name: 'inventoryBalance', type: 'TEXT'},
			{name: 'inventoryType', type: 'TEXT'},
			{name: 'inventoryName', type: 'TEXT'},
			{name: 'inventoryImage', type: 'TEXT'},
			{name: 'campaignDescription', type: 'TEXT'},
			{name: 'campaignFooterNote', type: 'TEXT'},
			{name: 'prizesToBeClaimed', type: 'TEXT'},
			{name: 'totalPrizeDonated', type: 'TEXT'},
			{name: 'achievedStepCount', type: 'TEXT'},
			{name: 'status', type: 'TEXT'},
			{name: 'lastUpdatedTime', type: 'TEXT'}
		    ]
		},
		{
		name:'mljCampaignTransaction',
		columns:[
			{name: 'campaignId', type: 'TEXT'},
			{name: 'achievedStepCount', type: 'TEXT'},
			{name: 'source', type: 'TEXT'},
			{name: 'lastUpdatedTime', type: 'DATETIME'},
			{name: 'startDateTime', type: 'DATETIME'}
		    ]
		},
		{
		name:'mljCourse',
		columns:[
			{name: 'courseId', type: 'INTEGER PRIMARY KEY AUTOINCREMENT'},
			{name: 'courseName', type: 'TEXT'},
			{name: 'courseDesc', type: 'TEXT'},
			{name: 'courseCreatedDate', type: 'TEXT'},
			{name: 'imagePath', type: 'TEXT'},
			{name: 'latlng', type: 'TEXT'},
			{name: 'userStepCount', type: 'TEXT'},
			{name: 'status', type: 'TEXT'},
			{name: 'source', type: 'TEXT'}
		    ]
		},
		{
		name:'mljUserProfile',
		columns:[
			{name: 'email', type: 'TEXT PRIMARY KEY NOT NULL'},
			{name: 'nickname', type: 'TEXT'},
			{name: 'gender', type: 'TEXT'},
			{name: 'yob', type: 'TEXT'},
			{name: 'deviceId', type: 'TEXT NOT NULL'},
			{name: 'dailyTarget', type: 'TEXT'},
			{name: 'oAuthToken', type: 'TEXT'},
			{name: 'bodyOfAttachment', type: 'TEXT'},
			{name: 'fileName', type: 'TEXT'},
			{name: 'batchNo', type: 'TEXT'},
			{name: 'activeCampaignId', type: 'TEXT'},
			{name: 'source', type: 'TEXT'},
			{name: 'lastUpdatedTime', type: 'TEXT'}
		    ]
		}]
    }
    return mljdbConstantModule;
});