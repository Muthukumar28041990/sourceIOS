define( [ "jquery" ], function() {
    console.log( "Loading reward.js" );
    var rewardModule = {
        initialize: function() {
        }
    };
    return rewardModule;
} );
