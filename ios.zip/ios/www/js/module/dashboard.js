define( [ "jquery", "./donation.js", "./synchronisation.js", "./mljDate.js","./common.js","./cordova.service.js","./mljWalkConstants.js", "./mljdbproc.js", "./mljObjectModel.js"], function($, donationModule, synchronisation, mljDate,commonModule,networkService,mljdbConstantModule, mljdbproc, mljObjectModel) {
    console.log( "Loading dashboard.js" );
    var targetSetReset;
	var dashboardModule = {
		counter: 0,
		chartDate:null,
        initialize: function() {
			this.pagecreate();
			dashboardModule.bind();
			commonModule.shrinkText();
        },
		pagecreate:function(){
			$(document).on("pagecontainershow", function (e, ui) {
				var currentpage = ui.toPage.prop("id");
                if ((currentpage === "dashboard-page")) {
					 $(document).bind('mobileinit',function(){
						$.mobile.changePage.defaults.changeHash = false;
						$.mobile.hashListeningEnabled = false;
						$.mobile.pushStateEnabled = false;
					});
					setTimeout(function(){
						navigator.splashscreen.hide();					
					},2000);
                   donationModule.updateDashboardView();
                   dashboardModule.counter = 1;
				   dashboardModule.enableDisablebtn(dashboardModule.counter);
				   dashboardModule.chartDate = new Date();
                }				
			});
		},
		bind : function() {
			$(document).off("click",".courseRecordContainer#course-recorded").on("click",".courseRecordContainer#course-recorded", function(e){
				 e.preventDefault();
				if(!networkService.connection()) {
	                commonModule.toaster({"text":checkConnectivity,"type":"error","timeout":3000, "modal":true});
	                return;
           		 }
           		 else
           		 {
           		 	  
                     $(':mobile-pagecontainer').pagecontainer('change', 'courseRecording/start-course-recording.html', {
                        transition: 'slide', 
                    }); 
           		 }
			});

			$(document).off("click",".walkmapContainer#map").on("click",".walkmapContainer#map", function(e){
				 e.preventDefault();
				if(!networkService.connection()) {
	                commonModule.toaster({"text":checkConnectivity,"type":"error","timeout":3000, "modal":true});
	                return;
           		 }
           		 else
           		 {
           		 	$(':mobile-pagecontainer').pagecontainer('change', 'walkmap/strolling-map.html', {
                        transition: 'slide', 
                    }); 
           		 }
			});

			$(document).on("click", "#details-button", function(e) {
				e.preventDefault();
				targetSetReset = window.localStorage.getItem("setTargetSteps");
				if(dashboardModule.counter == 0) return false;
				if(targetSetReset && dashboardModule.counter >= 1){
					$(':mobile-pagecontainer').pagecontainer('change', 'pedometer/chart.html', {
                        transition: 'slide',
						targetPg:dashboardModule.counter-1,
						targetDate:dashboardModule.chartDate
                    });
				}
				else{
					$(':mobile-pagecontainer').pagecontainer('change', 'pedometer/pedometer.html', {
                        transition: 'slide'
                    });
				}
			});
			$(document).on("click", ".dashArrow", function(e) {
				var datePrevNext = null;
		 		switch (e.currentTarget.name) {
	                case "left":
	                	dashboardModule.leftData();
						
	                    break;
	                case "right":
						dashboardModule.rightData();
	                    break;
	            }
	            
			});
			
			$.mobile.document.off("swipeleft", "#dashboard-page").on("swipeleft", "#dashboard-page",function(){
                dashboardModule.rightData();
			  });
			  $.mobile.document.off("swiperight", "#dashboard-page").on("swiperight", "#dashboard-page",function(){
              
			   dashboardModule.leftData();
			  });
		},
		leftData:function(){
		var datePrevNext = null;
		if (dashboardModule.counter > 8) return false;
		if(dashboardModule.counter <= 7){
						dashboardModule.counter = dashboardModule.counter + 1;
						dashboardModule.enableDisablebtn(dashboardModule.counter);
	                    datePrevNext = new Date(new Date().setDate(new Date().getDate() - (dashboardModule.counter-1)));
						dashboardModule.chartDate = datePrevNext;
		var dashDate = mljDate.getMLJDashFormat(datePrevNext);
	            $('#dash-date').text(dashDate);
	            datePrevNext !== null ? synchronisation.updateStepCountinDashboard(datePrevNext, datePrevNext) : 0;
		}			
		},
		rightData:function(){
		var datePrevNext = null;
		if (dashboardModule.counter <= 0)return false; 
		if(dashboardModule.counter === 1){dashboardModule.updateTotalsteps();dashboardModule.counter = dashboardModule.counter - 1;dashboardModule.enableDisablebtn(dashboardModule.counter);}
		if(dashboardModule.counter >= 2){
						dashboardModule.counter = dashboardModule.counter - 1;
						dashboardModule.enableDisablebtn(dashboardModule.counter);
	                    datePrevNext = new Date(new Date().setDate(new Date().getDate() - (dashboardModule.counter-1)));
						dashboardModule.chartDate = datePrevNext;
						var dashDate = mljDate.getMLJDashFormat(datePrevNext);
	            $('#dash-date').text(dashDate);
	            datePrevNext !== null ? synchronisation.updateStepCountinDashboard(datePrevNext, datePrevNext) : 0;		
			}				
		},
		enableDisablebtn: function(target) {
            var nextCls = $('.right-arrow');
            var prevCls = $('.left-arrow');
            switch (true) {
                case (target === 0):
                    nextCls.addClass("disabled");
                    prevCls.removeClass("disabled");
					nextCls.prop('disabled', true);
					prevCls.prop('disabled', false);
                    break;
                case (target > 7):
                    nextCls.removeClass("disabled");
                    prevCls.addClass("disabled");
					nextCls.prop('disabled', false);
					prevCls.prop('disabled', true);
                    break;
                default:
                    nextCls.removeClass("disabled");
                    prevCls.removeClass("disabled");
					nextCls.prop('disabled', false);
					prevCls.prop('disabled', false);
            }
        },
		updateTotalsteps:function(){
			sso = JSON.parse(commonModule.storage.getItem("sso"));
					if(sso){
						userinfo = {
							email: sso.email
						};
			}
			var total;
			if(networkService.connection()){
			dashboardModule.getLocalDBData().then(function(res){
					total = parseInt(res);
					$("#achieved-target").shrinkText(total);
					$('#dash-date').text("TOTAL");
				});	 
			/* dashboardModule.getTotalStepsSvc(userinfo).then(function(result){
				total = result[0].totalStepCount;
				$("#achieved-target").shrinkText(total);
				$('#dash-date').text("TOTAL");
				 dashboardModule.getTodaySteps().then(function(res){
					total = total + parseInt(res);
					$("#achieved-target").shrinkText(total);
					$('#dash-date').text("TOTAL");
				});	 		
			}); */
			}
            else commonModule.toaster({"text":checkConnectivity,"type":"error","timeout":3000, "modal":true});
		
		},
		getLocalDBData:function(){
			var deferred = $.Deferred();
			var query = 'SELECT Sum(achievedStepCount) AS achievedStepCount FROM ' + mljdbConstantModule.tables[1].name;
                $.when(mljdbproc.mljGetDataFromDB(query)).then(function(result) {
                    if (result !== null && result !== undefined && result.achievedStepCount !== undefined) {
                        if (result.achievedStepCount !== null) {
                            deferred.resolve(result.achievedStepCount);
                        } else {
                            deferred.resolve(0);
                        }

                    }

                }, function(error) {
                    if (error !== undefined && error !== null && error.status !== undefined && !error.status) {
                        //call common error function
                        deferred.reject(null);
                    }
                });
                return deferred.promise();
		},
		getTodaySteps:function(){
			var deferred = $.Deferred();
            var startDatetime = mljDate.getMLJStartDatetime();
            var endDatetime = mljDate.getMLJEndDatetime();
			var query = 'SELECT Sum(achievedStepCount) AS achievedStepCount FROM ' + mljdbConstantModule.tables[1].name + ' WHERE lastUpdatedTime BETWEEN Datetime("' + startDatetime + '") AND Datetime("' + endDatetime + '")';
                $.when(mljdbproc.mljGetDataFromDB(query)).then(function(result) {
                    if (result !== null && result !== undefined && result.achievedStepCount !== undefined) {
                        if (result.achievedStepCount !== null) {
                            deferred.resolve(result.achievedStepCount);
                        } else {
                            deferred.resolve(0);
                        }

                    }

                }, function(error) {
                    if (error !== undefined && error !== null && error.status !== undefined && !error.status) {
                        //call common error function
                        deferred.reject(null);
                    }
                });
                return deferred.promise();
		},
		getTotalStepsSvc: function(userinfo) {
			var deferred = $.Deferred();
           var sso = JSON.parse(commonModule.storage.getItem("sso"));
            var instUrl = sso.instanceUrl;
            var oauth = sso.accessToken;
            instUrl = instUrl + "/services/apexrest/MainDashBoard";
            var request = $.ajax({
                url: instUrl,
                type: "POST",
                contentType: 'application/json',
                headers: {
                    'Authorization': oauth
                },
                data: JSON.stringify(userinfo),
                dataType: "json"
            });
            request.done(function(msg) {
                //  var img = msg.Data[0].bodyOfAttachment;
                if (msg.Status === "SUCCESS") {
                    deferred.resolve(msg.Data);
                } 

            });
            request.fail(function(jqXHR, textStatus) {
                console.log(textStatus);
				 deferred.reject(null);
            });
			return deferred.promise();
        },
    };
    return dashboardModule;
} );
